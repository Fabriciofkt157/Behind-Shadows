---
titulo: "Cenoura"
subtitulo: "Otto Wern"
template: "character"
icone: "fa-user"
age: "24 anos"
birthday: "21/07"
sexo: "Masculino"
natureza: "Humano (renascido)"
origin: "Eards (realidade)"
natural_de: "Eards (realidade)"
parentesco: "Jhonatas e Amanda (melhores amigos)"
aliados: "Jhonatas e Amanda. Após o timeskip, Alan e Mike também se tornam aliados."
---

### Sobre
Jhonata, Amanda e Otto morreram ao mesmo tempo e foram juntos pro Novo Mundo. Nele, eles se juntaram ao Império de Avalest.

### Personalidade
Tranquilo e "desligado" a maior parte do tempo. Quando cercado por muitas pessoas que não conhece, tende a ficar retraído e tímido.

### Curiosidade
Jhonatas e Amanda o chamam de Cenoura devido ao seu cabelo ruivo — há algumas cenas reforçando isso, como piadas e seu aniversário onde recebe uma roupa laranja para combinar com o apelido. De início, Alan acha que seu nome é Otavio e Otto é seu apelido, pouco tempo depois, Alan o chama de Cenoura.