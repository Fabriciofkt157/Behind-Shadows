---
titulo: "Mands / Mandinha"
subtitulo: "Amanda Mullef"
template: "character"
icone: "fa-user"
age: "22 anos"
birthday: "19/05"
sexo: "Feminino"
natureza: "Humano (renascido)"
origin: "Eards (realidade)"
natural_de: "Eards (realidade)"
parentesco: "Otto e Jhonatas (melhores amigos)"
aliados: "Otto e Jhonatas. Após o timeskip, Alan e Mike também se tornam aliados."
---

### Sobre
Jhonata, Amanda e Otto morreram ao mesmo tempo e foram juntos pro Novo Mundo. Nele, eles se juntaram ao Império de Avalest.

### Personalidade
Sorridente a maior parte do tempo, pouco tímida.

### Curiosidade
Amanda tem uma "quedinha" pelo Alan, mas prefere não rivalizar com Raika.
