---
titulo: "Jhonata / loiro / John"
subtitulo: "Jhonatas Thaif"
template: "character"
icone: "fa-user"
age: "21 anos"
birthday: "12/01"
sexo: "Masculino"
natureza: "Humano (renascido)"
origin: "Eards (realidade)"
natural_de: "Eards (realidade)"
parentesco: "Otto e Amanda (melhores amigos)"
aliados: "Otto e Amanda. Após o timeskip, Alan e Mike também se tornam aliados."
---

### Sobre
Jhonata, Amanda e Otto morreram ao mesmo tempo e foram juntos pro Novo Mundo. Nele, eles se juntaram ao Império de Avalest.

### Personalidade
Extremamente amigável com seus amigos e "pavio curto" com aqueles que estão no seu caminho.

### Curiosidade
Eventualmente Otto e Amanda chamam Jhonatas de loiro. Mike o conhece como Jhonata (sem o s) — ele entendeu assim e acaba confundindo a maior parte do tempo. Alan o chama de John por pura preguiça.