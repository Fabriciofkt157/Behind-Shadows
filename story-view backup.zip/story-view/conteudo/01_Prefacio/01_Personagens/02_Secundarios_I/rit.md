---
titulo: "Rit"
subtitulo: "Ritain Mourk"
template: "character"
icone: "fa-user"
age: "23 anos"
birthday: "21/02"
sexo: "Masculino"
natureza: "Humano"
origin: "Median (realidade)"
natural_de: "Median (realidade)"
parentesco: "Deni (irmão), Mike (melhor amigo)"
aliados: "Mike, Alan, Raika, Deni"
image_url: "https://behind.fabriciofkt157.me/game-features/concept-arts/Rit_retrato.png"
---

### Sobre
Rit fugiu com Deni para Avalest (cidade principal) após um ataque a antiga vila onde moravam (na época, Deni tinha 3 anos e Rit 10), nele, seus amigos e familiares foram mortos.

### Personalidade
Rit é uma pessoa emocionalmente forte, raramente se deixa abalar por qualquer situação Ele não é excessivamente alegre, nem propenso à melancolia; em vez disso, Rit sente exatamente o que o momento exige. Sua empatia é uma característica notável, permitindo que ele se sensibilize profundamente com as dificuldades dos outros, o que o leva frequentemente a ajudar aqueles que o cercam
