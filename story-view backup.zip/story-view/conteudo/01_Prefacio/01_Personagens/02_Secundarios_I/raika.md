---
titulo: "Raika"
subtitulo: "Raika Tirouf"
template: "character"
icone: "fa-user"
age: "21 anos"
birthday: "01/04"
sexo: "Feminino"
natureza: "Humano (renascido)"
origin: "Median (realidade)"
natural_de: "Median (realidade)"
parentesco: "Alan (cônjuge)"
aliados: "Mike, Alan, Rit, Deni"
image_url: "https://behind.fabriciofkt157.me/game-features/concept-arts/Raika_retrato.png"
---

### Sobre
Raika foi uma dos generais do Exército das Sombras como um agente duplo entre o Império de Median e o Exército. Em um tempo ajudava o Exército a tomar posse dos recursos de Median, em outro, ajudava Median fornecendo informaçōes em troca de sua liberdade; essa relação é desfeita oficialmente quando a Sky (organização) é formada, agora Raika deixa seu posto como General. Após seu interesse romântico com Alan ser revelado, Raika conta que ela era o verdadeiro General do Submundo e não o cara que eles derrotaram no torneio quando Alan estava corrompido.

### Personalidade
Raika é uma pessoa de temperamento ”bravo” e ”raivoso”, o que a leva a agir e atacar impulsivamente em diversas situações. No entanto, ela demonstra uma inteligência afiada em combate e na criação de estratégias. Geralmente, Raika é um pouco infeliz e raramente sorri, o que deixa de acontecer ao lado de Alan.

### Curiosidade
Raika se apaixona por Alan depois de um tempo convivendo juntos; uma das cenas do jogo mostra os dois dançando juntos, Raika revela seu interesse amoroso e os dois ficam juntos (um pouco antes de metade do jogo).
