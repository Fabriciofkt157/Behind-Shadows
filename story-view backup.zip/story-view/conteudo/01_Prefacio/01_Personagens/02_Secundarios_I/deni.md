---
titulo: "Deni"
subtitulo: "Deniel Mourk"
template: "character"
icone: "fa-user"
age: "16 anos"
birthday: "01/04"
sexo: "Masculino"
natureza: "Humano (renascido)"
origin: "Median (realidade)"
natural_de: "Median (realidade)"
parentesco: "Rit (irmão), Mike (melhor amigo)"
aliados: "Mike, Alan, Raika, Rit"
image_url: "https://behind.fabriciofkt157.me/game-features/concept-arts/Deni_retrato.png"
---

### Sobre
Deni foi levado por Rit a Avalest após o ataque, no entanto, não tem lembranças disso por ser muito pequeno quando aconteceu.

### Personalidade
Deni é amigável na maior parte do tempo, mostrando maturidade na maioria das situações, embora ocasionalmente cometa alguns deslizes.

### Curiosidade
Deni tem o hábito de fazer piadas ruins de vez em quando ou ”pregar peças” em seus companheiros durante longas jornadas, trazendo um toque de humor às suas interaçõoes.
