---
titulo: "Mike"
subtitulo: "Maicon Jousan"
template: "character"
icone: "fa-user"
age: "14 anos"
birthday: "17/12"
sexo: "Masculino"
natureza: "Humano (renascido)"
origin: "Eards (realidade)"
natural_de: "Eards (realidade)"
parentesco: "Alan (melhor amigo / irmão (vida real));"
aliados: "Alan, Raika, Deni, Rit"
image_url: "https://behind.fabriciofkt157.me/game-features/concept-arts/Mike_retrato.png"
---

### Sobre
Mike passa por algumas situações estressantes na vida real, essas situações são retratadas no sonho de Mike sob outra perspectiva, dessa vez, esses problemas podem ser resolvidos.

### Personalidade
Mike é geralmente alegre e espontâneo. Ele é uma pessoa extrovertida, com uma mentalidade um pouco imatura e impulsiva. Ao contrário de Alan, Mike costuma expressar tudo o que pensa e adora socializar. Ele tem uma facilidade natural para fazer amigos, o que, por vezes, incomoda algumas pessoas.

### Curiosidade
Alan e Mike são irmãos por parte de mãe, mas têm pais diferentes, o que explica seus sobrenomes distintos. Alan carrega o sobrenome ”Dount” de seu pai, enquanto Mike herda o sobrenome ”Jousan”. O Homem Misterioso menciona apenas os sobrenomes aos quais os personagens têm maior vínculo, refletindo a tradição em que cada pessoa representa uma família em batalhas. Alan, portanto, luta pela família ”Dount”, enquanto Mike luta pela família ”Jousan”, reforçando a ideia de que eles pertencem a linhagens diferentes, apesar de serem irmãos

