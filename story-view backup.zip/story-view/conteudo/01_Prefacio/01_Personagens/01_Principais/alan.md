---
titulo: "Alan / Lon"
subtitulo: "Alan Dount"
template: "character"
icone: "fa-user"
age: "17 anos"
birthday: "14/02"
sexo: "Masculino"
natureza: "Humano (renascido)"
origin: "Eards (realidade)"
natural_de: "Eards (realidade)"
parentesco: "Mike (melhor amigo / irmão (vida real)), Raika (cônjuge)"
aliados: "Mike, Raika, Deni, Rit"
image_url: "https://behind.fabriciofkt157.me/game-features/concept-arts/Alan_retrato.png"
---

### Sobre
Alan é irmão mais velho de Mike, na vida real está se preparando para viver sua própria vida, o que Mike distorce e enxerga como um "adeus". Alan foi abusado por seu tio Mark quando tinha 4 anos, no entanto, quando relata isso a sua família, todos acham que Alan está tentando "chamar atenção" e ignoram. Isso torna Alan quieto e desconfiado de todos, muitas vezes preferindo ficar sozinho; no sonho de Mike, Mark é o Homem Misterioso (sua identidade será revelada apenas no final do jogo) que também é o antagonista principal da história, além de se infiltrar como um aliado de Mike e Alan, mostrando a realidade traiçoeira da confiança.

### Personalidade
Alan é reservado, um pouco rabugento e geralmente muito inteligente. Ele pode parecer sombrio as vezes, mas é, no fundo, uma boa pessoa. No entanto, se algo se colocar entre ele e seus objetivos, Alan não hesitará em mostrar um lado menos amigável. Alan pode se mostrar um pouco ”fofinho” em alguns diálogos, contrapondo seu lado rabugento.

### Curiosidade
Em uma das cenas com Mike, Alan revela que seu irmão costumava chamá-lo de ”Lon” e sugere que Mike também pode usar esse apelido se quiser. Eventualmente, Mike chama o Alan por esse nome. Após ser corrompido e posteriormente controlar as Sombras, Alan não precisa dormir, no entanto, é comum encontra-lo dormindo por aí (ele apenas gosta).

