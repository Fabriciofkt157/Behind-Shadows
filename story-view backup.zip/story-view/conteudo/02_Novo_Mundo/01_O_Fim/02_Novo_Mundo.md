---
titulo: "Chegada ao Novo Mundo"
subtitulo: "Cutscene: Novo Mundo"
template: cutscene
ordem: 2
icone: fa-film
---

**Mike:** ...Isso é...

**Alan:** *[com ódio]* VOCÊ!

*(Alan acerta um soco no rosto de Mike e o segura pelo braço)*

**Alan:** *[com ódio]* EU NEM TE CONHEÇO E ME ARRASTOU PRA ESSE FIM DE MUNDO!

**Mike:** Sério mesmo que prefere renascer?

**Alan:** *[com raiva contida]* IDIOTA.

**Mike:** Escuta... o que te faz pensar que renascer resolveria alguma coisa?

**Alan:** *[triste]* Eu nunca pude escolher o que aconteceria com a minha vida... nem no final dela.

**Mike:** Ah, é? Então me diz: você reencarnou... se fosse abortado, teria alguma escolha? Acha que aquele cara teria dado uma atenção especial? Imagina como seria renascer, mas com alguma deficiência. Em vez disso, você está aqui, "perfeitinho", bem na minha frente.

**Alan:** *[com ódio]* DE QUE MERDA ISSO TE IMPORTA?! NÃO É A SUA VIDA, É A MINHA! QUEM PASSARIA POR ISSO SERIA EU!

**Mike:** Olha ao redor. Isso aqui é sua segunda chance. Esse lugar enfrenta problemas completamente diferentes dos que você vivia.

**Mike:** *[com olhar sério]* Se prefere renascer naquele mundo e enfrentar os mesmos problemas, só que com uma cara nova, numa vida miserável... Então o problema nunca foi o mundo em que vivia... e sim você.

**Alan:** ...

**Mike:** *[amigável]* Vamos de novo. Olha, de qualquer forma, a gente tá aqui. Você ainda vai poder renascer. Tenta dar uma chance... se morrer de novo, é só renascer e pronto. Vamo tentar achar um lugar pr—
*(Alan vira as costas e começa a andar; Mike o segue)*

**Mike:** Onde tá indo?

**Alan:** *[bravo]* CAI FORA! Cada um pro seu lado.

**Mike:** *[triste]* Ah, qual é!

**Alan:** Se manda.

